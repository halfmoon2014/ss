﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///RightChecker 的摘要说明
/// </summary>
public class RightChecker
{
	public RightChecker()
	{
		//
		//TODO: 在此处添加构造函数逻辑
		//
	}
    public static bool HasRight(string userid, string module)
    {
        //进行权限校验，
        return true;
    }

}